export interface DividerProps {
    className?: string;
    children?: React.ReactNode;
}